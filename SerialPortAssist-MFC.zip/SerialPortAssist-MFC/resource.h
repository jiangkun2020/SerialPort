//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SerialPort_New.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SERIALPORT_NEW_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_DATA_FORMAT          132
#define IDC_BUTTON_OPEN                 1001
#define IDC_BUTTON_CLEAN                1002
#define IDC_BUTTON_SEND                 1003
#define IDC_BUTTON__CLEAN_COUNT_        1004
#define IDC_EDIT_RECEIVE                1005
#define IDC_EDIT_SEND                   1006
#define IDC_BUTTON_DATA_FORMAT          1007
#define IDC_STATIC_RECEIVE_COUNT        1008
#define IDC_COMBO_BANDRATE              1009
#define IDC_STATIC_SEND_COUNT           1010
#define IDC_BUTTON__ABOUT_AUTHOR        1011
#define IDC_COMBO_COM_NUM               1013
#define IDC_CHECK_HEX16_DISP            1014
#define IDC_CHECK_HEX16_SEND            1015
#define IDC_CHECK_TIMER_SEND            1017
#define IDC_EDIT_TEMER_PERIOD           1018
#define IDC_STATIC_RECEIVE_LINE_COUNT   1019
#define IDC_STATIC_THREAD_COUNT_NO_USE  1020
#define IDC_COMBO_DATA_BIT              1022
#define IDC_COMBO_STOP_BIT              1023
#define IDC_COMBO_CHECK_BIT             1024
#define IDC_STATIC_DATA_BIT             1025
#define IDC_STATIC_STOP_BIT             1026
#define IDC_STATIC_CHECK_BIT            1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
